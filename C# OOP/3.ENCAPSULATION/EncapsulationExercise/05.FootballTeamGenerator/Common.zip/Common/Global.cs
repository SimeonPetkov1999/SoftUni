﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _05.FootballTeamGenerator
{
    public static class Global
    {
        public static string statsExeptionMessage = "{0} should be between {1} and {2}.";
        public static string nameExeptionMessage = "A name should not be empty.";
        public static string removePlayerExeptionMessage = "Player {0} is not in {1} team.";
        public static string validateTeamExeptionMessage = "Team {0} does not exist.";
        
    }
}
