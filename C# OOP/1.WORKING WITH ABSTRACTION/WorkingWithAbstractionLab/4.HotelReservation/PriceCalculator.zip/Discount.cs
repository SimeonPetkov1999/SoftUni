﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _4.HotelReservation
{
    public enum Discount
    {
        None,
        SecondVisit = 10,
        VIP = 20,
    }
}
