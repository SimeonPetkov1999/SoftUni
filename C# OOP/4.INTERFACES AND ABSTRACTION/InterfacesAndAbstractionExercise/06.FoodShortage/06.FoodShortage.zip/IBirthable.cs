﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _06.FoodShortage
{
    interface IBirthable
    {
        public string BirthDate { get;}
        public string BirthYear { get; }
    }
}
