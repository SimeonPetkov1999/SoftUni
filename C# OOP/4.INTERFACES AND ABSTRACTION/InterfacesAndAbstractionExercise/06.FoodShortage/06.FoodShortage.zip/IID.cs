﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _06.FoodShortage
{
    interface IID
    {
        public string ID { get;}
    }
}
