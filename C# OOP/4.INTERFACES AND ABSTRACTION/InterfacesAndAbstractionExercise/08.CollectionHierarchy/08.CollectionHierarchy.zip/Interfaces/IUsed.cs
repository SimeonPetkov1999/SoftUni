﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _08.CollectionHierarchy.Interfaces
{
    interface IUsed
    {
        public int Used { get;}
    }
}
