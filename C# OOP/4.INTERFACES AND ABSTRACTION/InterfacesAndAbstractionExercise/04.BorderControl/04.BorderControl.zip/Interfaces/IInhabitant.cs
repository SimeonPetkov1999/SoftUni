﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _04.BorderControl.Interfaces
{
    interface IInhabitant
    {
        public string ID { get;}
    }
}
