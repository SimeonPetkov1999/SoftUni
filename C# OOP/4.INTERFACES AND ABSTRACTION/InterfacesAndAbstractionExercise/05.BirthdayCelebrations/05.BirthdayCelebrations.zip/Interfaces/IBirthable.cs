﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _05.BirthdayCelebrations.Interfaces
{
    interface IBirthable
    {
        public string BirthDate { get;}
        public string BirthYear { get; }
    }
}
