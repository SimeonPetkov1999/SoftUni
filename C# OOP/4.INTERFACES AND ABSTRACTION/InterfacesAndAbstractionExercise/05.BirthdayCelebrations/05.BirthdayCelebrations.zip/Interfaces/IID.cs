﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _05.BirthdayCelebrations.Interfaces
{
    interface IID
    {
        public string ID { get;}
    }
}
