﻿using _05.BirthdayCelebrations.Interfaces;
using _05.BirthdayCelebrations.Models;
using System;
using System.Collections.Generic;
using System.Linq;

namespace _05.BirthdayCelebrations
{
    class Program
    {
        static void Main(string[] args)
        {
            var str = "123456789";
            var last4 = str.TakeLast(4).ToString();

            var list = new List<IBirthable>();
            while (true)
            {
                var commandArgs = Console.ReadLine()
                    .Split(' ', StringSplitOptions.RemoveEmptyEntries);
                if (commandArgs[0] == "End")
                {
                    break;
                }

                var type = commandArgs[0];
                if (type== "Citizen")
                {
                    var citizenName = commandArgs[1];
                    var citizenAge = int.Parse(commandArgs[2]);
                    var citizenID = commandArgs[3];
                    var citizenBirthDate = commandArgs[4];
                    var citizen = new Cititzen(citizenName, citizenAge, citizenID,citizenBirthDate);
                    list.Add(citizen);
                }
                else if(type=="Pet")
                {
                    var petName = commandArgs[1];
                    var petBirthDate = commandArgs[2];
                    var pet = new Pet(petName, petBirthDate);
                    list.Add(pet);
                }
            }

            var year = Console.ReadLine();

            list = list.Where(x => x.BirthYear == year).ToList();
            if (list.Count>0)
            {
                list.ForEach(x => Console.WriteLine(x.BirthDate));
            }
            
            

            //list = list.Where(x => x.ID.EndsWith(lastDigits)).ToList();
            //list.ForEach(x => Console.WriteLine(x.ID));
        }
    }
}
