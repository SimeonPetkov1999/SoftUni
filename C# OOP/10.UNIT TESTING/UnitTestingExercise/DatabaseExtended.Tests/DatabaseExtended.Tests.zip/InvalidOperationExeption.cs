﻿namespace Tests
{
    internal class InvalidOperationExeption
    {
    }
}