﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _01.Vehicles.Common
{
    class ExeptionMessages
    {
        public static string refuelExeption = "{0} needs refueling";

    }
}
