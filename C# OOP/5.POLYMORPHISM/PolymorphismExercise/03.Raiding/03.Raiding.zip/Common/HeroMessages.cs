﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _03.Raiding.Common
{
    class HeroMessages
    {
        public static string heroHealed = "{0} - {1} healed for {2}";
        public static string heroHit = "{0} - {1} hit for {2} damage";
    }
}
