﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _04.WildFarm.Enumerations
{
    enum HensFood
    {
        Vegetable,
        Fruit,
        Meat,
        Seeds
    }
}
