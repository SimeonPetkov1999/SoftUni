﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _04.WildFarm.Enumerations
{
    enum MiceFood
    {
        Vegetable,
        Fruit
    }
}
