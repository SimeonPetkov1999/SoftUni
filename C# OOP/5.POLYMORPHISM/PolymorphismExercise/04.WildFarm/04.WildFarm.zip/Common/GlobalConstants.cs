﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _04.WildFarm.Common
{
    class GlobalConstants
    {
        public static double HenWeightIncreaseValue = 0.35;
        public static double OwlWeightIncreaseValue = 0.25;
        public static double MouseWeightIncreaseValue = 0.10;
        public static double CatWeightIncreaseValue = 0.30;
        public static double DogWeightIncreaseValue = 0.40;
        public static double TigeWeightIncreaseValue = 1.00;
    }
}
