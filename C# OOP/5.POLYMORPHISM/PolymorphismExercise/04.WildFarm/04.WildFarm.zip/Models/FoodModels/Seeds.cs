﻿namespace _04.WildFarm.Models.FoodModels
{
    class Seeds : Food
    {
        public Seeds(int quantity) 
            : base(quantity)
        {
        }
    }
}
