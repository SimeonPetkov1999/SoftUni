﻿namespace _04.WildFarm.Models.FoodModels
{
    class Vegetable : Food
    {
        public Vegetable(int quantity) 
            : base(quantity)
        {
        }
    }
}
