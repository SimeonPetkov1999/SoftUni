﻿namespace _04.WildFarm.Models.FoodModels.Interfaces
{
    interface IFood
    {
        int Quantity { get; }
    }
}
