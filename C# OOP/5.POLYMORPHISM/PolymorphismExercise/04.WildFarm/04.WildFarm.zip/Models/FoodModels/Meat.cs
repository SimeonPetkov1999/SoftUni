﻿namespace _04.WildFarm.Models.FoodModels
{
    class Meat : Food
    {
        public Meat(int quantity) 
            : base(quantity)
        {
        }
    }
}
