﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _04.WildFarm.Core.Interfaces
{
    interface IEngine
    {
        public void Run();
    }
}
