﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace _07.RawData
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());

            var allCars = new List<Car>();
            for (int i = 0; i < n; i++)
            {
                var carInfo = Console.ReadLine()
                    .Split(" ", StringSplitOptions.RemoveEmptyEntries);
                var carModel = carInfo[0];
                var speed = double.Parse(carInfo[1]);
                var power = double.Parse(carInfo[2]);
                var weight = double.Parse(carInfo[3]);
                var type = carInfo[4];
                var tire1Pressure = double.Parse(carInfo[5]);
                var tire1Age = double.Parse(carInfo[6]);
                var tire2Pressure = double.Parse(carInfo[7]);
                var tire2Age = double.Parse(carInfo[8]);
                var tire3Pressure = double.Parse(carInfo[9]);
                var tire3Age = double.Parse(carInfo[10]);
                var tire4Pressure = double.Parse(carInfo[11]);
                var tire4Age = double.Parse(carInfo[12]);

                var currentCarEngine = new Engine(speed, power);
                var currentCarCargo = new Cargo(weight, type);
                var curerntCarTire = new Tire[4];
                curerntCarTire[0] = new Tire(tire1Pressure,tire1Age);
                curerntCarTire[1] = new Tire(tire2Pressure,tire2Age);
                curerntCarTire[2] = new Tire(tire3Pressure,tire3Age);
                curerntCarTire[3] = new Tire(tire4Pressure,tire4Age);
             
                allCars.Add(new Car(carModel, currentCarEngine, currentCarCargo, curerntCarTire));
                
            }

            var command = Console.ReadLine();
            if (command=="flamable")
            {
                allCars = allCars
                    .Where(x => x.Cargo.CargoType == "flamable")
                    .Where(x => x.Engine.EnginePower > 250)
                    .ToList();
            }
            else
            {
                allCars = allCars
                    .Where(x => x.Cargo.CargoType == "fragile")
                    .Where(x => x.Tires.Any(x => x.TirePressure < 1))
                    .ToList();
            }

            foreach (var car in allCars)
            {
                Console.WriteLine(car.Model);
            }
        }
    }
}
